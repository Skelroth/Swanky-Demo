<div class="footer">
  <p>Powered by Swanky LAN Interface</p>
</div>
</body>
</html>